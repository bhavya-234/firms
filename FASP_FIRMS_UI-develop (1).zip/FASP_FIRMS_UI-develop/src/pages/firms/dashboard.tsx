import React, { useEffect, useState } from "react"
import Head from "next/head"
import { Container, Row, Col, Accordion, Modal, Button } from "react-bootstrap"
import { useRouter } from "next/router"
import { useAppDispatch } from "@/redux/hooks"
import { KeepLoggedIn } from "@/GenericFunctions"
import CryptoJS from "crypto-js"

const FirmDashboard = () => {
  useEffect(() => {
    require("bootstrap/dist/js/bootstrap.bundle.min.js")
  }, [])

  const router = useRouter()
  const dispatch = useAppDispatch()
  const [loginDetails, setLoginDetails] = useState<any>({})
  const [showform1Modal, setShowform1Modal] = useState(false)
  const [showform2Modal, setShowform2Modal] = useState(false)
  const [showform3Modal, setShowform3Modal] = useState(false)

  useEffect(() => {
    localStorage.removeItem("PaymentDone")
    let data: any = localStorage.getItem("FASPLoginDetails")
    if (data && data != "" && process.env.SECRET_KEY) {
      let bytes = CryptoJS.AES.decrypt(data, process.env.SECRET_KEY)
      data = JSON.parse(bytes.toString(CryptoJS.enc.Utf8))
    }
    if (data && data.token) {
      setLoginDetails(data)
    }
    if (KeepLoggedIn()) {
    }
  }, [])

  const redirectToPage = (location: string) => {
    router.push({
      pathname: location,
    })
  }

  return (
    <>
      <Head>
        <title>E-Registration of Firms</title>
        <link rel="icon" href="/igrsfavicon.ico" />
      </Head>

      {loginDetails && loginDetails?.userType && loginDetails?.userType == "user" && (
        <div className="societyRegSec">
          <Container>
            <Row>
              <Col lg={12} md={12} xs={12}>
                <div className="d-flex justify-content-between page-title mb-2">
                  <div className="pageTitleLeft">
                    <h1>E-Registration of Firms</h1>
                  </div>
                </div>
              </Col>
            </Row>
          </Container>

          <div className="dashboardRegSec">
            <Container>
              <Row className="dashboardTopList justify-items-center">
                <Col lg={3} md={3} xs={12} className="mb-4 dashboardFirm">
                  <div className="dashboardChangesInfo d-flex align-items-center">
                    <div className="dashboardFirmImg">
                      <img src="/assets/firm-reg-icon.jpg" alt="Firm Registration" />
                    </div>
                    <div className="dashboardFirmRight">
                      <h6>Firm Registration</h6>
                      <div className="d-flex justify-content-between">
                        <p className="mrg">
                          Fee - <strong>500/-</strong>
                        </p>
                      </div>
                    </div>
                  </div>
                </Col>

                <Col lg={3} md={3} xs={12} className="mb-4 dashboardAddress">
                  <div className="dashboardChangesInfo d-flex align-items-center">
                    <div className="dashboardFirmImg">
                      <img src="/assets/address-change-icon.jpg" alt="Address Change" />
                    </div>
                    <div className="dashboardFirmRight">
                      <h6>Address Change Request</h6>
                      <div className="d-flex justify-content-between">
                        <p className="mrg">
                          Fee - <strong>100/-</strong> (per person)
                        </p>
                      </div>
                    </div>
                  </div>
                </Col>

                <Col lg={3} md={3} xs={12} className="mb-4 dashboardReconstitution">
                  <div className="dashboardChangesInfo d-flex align-items-center">
                    <div className="dashboardFirmImg">
                      <img src="/assets/reconstitution-icon.jpg" alt="Reconstitution" />
                    </div>
                    <div className="dashboardFirmRight">
                      <h6>Reconstitution of Firm</h6>
                      <div className="d-flex justify-content-between">
                        <p className="mrg">
                          Fee - <strong>300/-</strong>
                        </p>
                      </div>
                    </div>
                  </div>
                </Col>

                <Col lg={3} md={3} xs={12} className="mb-4 dashboardCertified">
                  <div className="dashboardChangesInfo d-flex align-items-center">
                    <div className="dashboardFirmImg">
                      <img src="/assets/certified-icon.jpg" alt="Certified" />
                    </div>
                    <div className="dashboardFirmRight">
                      <h6>Certified Copy of Firm</h6>
                      <div className="d-flex justify-content-between">
                        <p className="mrg">
                          Fee - <strong>300/-</strong>
                        </p>
                      </div>
                    </div>
                  </div>
                </Col>
              </Row>
            </Container>
          </div>

          <div className="dahboardProcedureSec">
            <Container>
              <Row>
                <Col lg={12} md={12} xs={12}>
                  <Accordion defaultActiveKey="2">
                    <Accordion.Item eventKey="2">
                      <Accordion.Header>
                        E-Registration of Firm (Online Application Form)
                      </Accordion.Header>
                      <Accordion.Body>
                        <div className="panelDesc">
                          <p>
                            <a style={{ cursor: "pointer" }} onClick={() => { setShowform1Modal(true) }}>
                              <strong>Click here for Online Application Form</strong>
                            </a>
                          </p>
                        </div>
                      </Accordion.Body>
                    </Accordion.Item>

                    <Accordion.Item eventKey="3">
                      <Accordion.Header>Status of Application</Accordion.Header>
                      <Accordion.Body>
                        <div className="panelDesc">
                          <p>
                            <a href="/firms">
                              <strong>Click here for Status of Application Form</strong>
                            </a>
                          </p>
                        </div>
                      </Accordion.Body>
                    </Accordion.Item>

                    <Accordion.Item eventKey="4">
                      <Accordion.Header>Download of Registration Certificate</Accordion.Header>
                      <Accordion.Body>
                        <div className="panelDesc">
                          <p>
                            <a href="/firms/downloadCertificate">
                              <strong>Click here to Download Certificate</strong>
                            </a>
                          </p>
                        </div>
                      </Accordion.Body>
                    </Accordion.Item>

                    {/* <Accordion.Item eventKey="5">
                      <Accordion.Header>Reconstitution of Firm</Accordion.Header>
                      <Accordion.Body>
                        <div className="panelDesc">
                          <p>
                            <a style={{ cursor: "pointer" }} onClick={() => { setShowform3Modal(true) }}>
                              <strong>Click here for Reconstitution of Firm</strong>
                            </a>
                          </p>

                          <p>
                            <strong>Description :</strong> This service is available to any firm
                            which wants to add/delete partners. Required document is uploaded and
                            department after verification can approve or reject the request.
                          </p>

                          <h6>Documents Needed :</h6>

                          <div className="mb-3">
                            <ol>
                              <li>Online Application</li>
                              <li>
                                The firm shall submit the original acknowledgment, statutory form,
                                partnership deed effecting reconstitution of firm through
                                courier/RPAD or in person to the Registrar of Firms concerned. The
                                approval shall be given within 3 working days from the time of
                                receipt of original papers, if every thing is in order.
                              </li>
                            </ol>
                          </div>

                          <p>
                            Approval Authority :Registrar of Firms & District Registrar Concerned
                          </p>
                        </div>
                      </Accordion.Body>
                    </Accordion.Item> */}

                    {/* <Accordion.Item eventKey="6">
                    <Accordion.Header>Certified Copy of Registration Certificate</Accordion.Header>
                    <Accordion.Body>
                      <div className="panelDesc">
                        <p>
                          <a href="/firms/downloadByLawCertificate">
                            <strong>Click here for the link</strong>
                          </a>
                        </p>

                        <p>
                          <strong>Description :</strong> This service is available when citizen
                          wants a copy of registration certificate of registered firm. After
                          registration of Firm, original Certificate of Registration is delivered to
                          the firm. Later, anybody can request for certified copy.
                        </p>

                        <h6>Required Documents :</h6>

                        <p>Online Applicant</p>

                        <p>
                          <strong>Service Delivery :</strong> Download Online
                        </p>
                      </div>
                    </Accordion.Body>
                  </Accordion.Item> */}

                    {/* <Accordion.Item eventKey="7">
                      <Accordion.Header>Address Change Request</Accordion.Header>
                      <Accordion.Body>
                        <div className="panelDesc">
                          <p>
                            <strong>
                              <a style={{ cursor: "pointer" }} onClick={() => { setShowform2Modal(true) }}>Click here for Alteration In Firm</a>
                            </strong>
                          </p>

                          <p>
                            <strong>Description : </strong> This service can be availed by any Firm
                            which wants to change/add/delete a business premises, godown, branch
                            office etc. Required document is uploaded and originals are submitted in
                            DR Office concerned. Department after verification can approve or reject
                            the request.
                          </p>

                          <h6>Documents Needed :</h6>

                          <div className="mb-3">
                            <ol>
                              <li>Online Application</li>

                              <li>
                                The firm shall submit the original acknowledgment and statutory form
                                through courier/RPAD or in person to the Registrar of Firms
                                concerned. The approval shall be given within 3 working days from
                                the time of receipt of original papers, if everything is in order.
                              </li>
                            </ol>
                          </div>

                          <p>
                            Approval Authority :Registrar of Firms & District Registrar concerned
                          </p>
                        </div>
                      </Accordion.Body>
                    </Accordion.Item> */}
                  </Accordion>
                </Col>
              </Row>
            </Container>
          </div>
        </div>
      )}
      {(!loginDetails?.userType || loginDetails?.userType != "user") && (
        <div className="societyRegSec">
          <Container>
            <Row>
              <Col lg={12} md={12} xs={12}>
                <div className="d-flex justify-content-between page-title mb-2">
                  <div className="pageTitleLeft">
                    <h1>Unauthorized page</h1>
                  </div>
                </div>
              </Col>
            </Row>
          </Container>
        </div>
      )}
      <Modal show={showform1Modal} onHide={()=>{setShowform1Modal(false)}} style={{paddingTop:"100px"}}>
        <Modal.Header closeButton>
          <Modal.Title>CheckList</Modal.Title>
        </Modal.Header>
        <Modal.Body className="text-start">
          <ul>
            <li><p>  Aadhaar Numbers of All Partners</p></li>
            <li><p> Partnership Deed</p></li>
            <li><p> Lease Agreement or Affidavit</p></li>
            <li><p> Self Signed Declaration</p></li>
          </ul>
        </Modal.Body>
        <Modal.Footer>
          <div style={{ alignItems: "flex-end" }}>
            <Button variant="primary" onClick={() => { router.push('/firms/form1') }}>
              Proceed
            </Button>
            <Button variant="secondary" className="ms-2" onClick={() => setShowform1Modal(false)}>
              Cancel
            </Button>
          </div>
        </Modal.Footer>
      </Modal>
      <Modal show={showform2Modal} onHide={()=>{setShowform2Modal(false)}} style={{paddingTop:"100px"}}>
        <Modal.Header closeButton>
          <Modal.Title>CheckList</Modal.Title>
        </Modal.Header>
        <Modal.Body className="text-start">
          <ul>
            <li><p>  Aadhaar Numbers of All Partners</p></li>
            <li><p> Partnership Deed</p></li>
            <li><p> Lease Agreement or Affidavit</p></li>
            <li><p> Self Signed Declaration</p></li>
          </ul>
        </Modal.Body>
        <Modal.Footer>
          <div style={{ alignItems: "flex-end" }}>
            <Button variant="primary" onClick={() => { router.push('/firms/form2') }}>
              Proceed
            </Button>
            <Button variant="secondary" className="ms-2" onClick={() => setShowform2Modal(false)}>
              Cancel
            </Button>
          </div>
        </Modal.Footer>
      </Modal>
      <Modal show={showform3Modal} onHide={()=>{setShowform3Modal(false)}} style={{paddingTop:"100px"}}>
        <Modal.Header closeButton>
          <Modal.Title>CheckList</Modal.Title>
        </Modal.Header>
        <Modal.Body className="text-start">
          <ul>
            <li><p>  Aadhaar Numbers of All Partners</p></li>
            <li><p> Partnership Deed</p></li>
            <li><p> Lease Agreement or Affidavit</p></li>
            <li><p> Self Signed Declaration</p></li>
          </ul>
        </Modal.Body>
        <Modal.Footer>
          <div style={{ alignItems: "flex-end" }}>
            <Button variant="primary" onClick={() => { router.push('/firms/form3') }}>
              Proceed
            </Button>
            <Button variant="secondary" className="ms-2" onClick={() => setShowform3Modal(false)}>
              Cancel
            </Button>
          </div>
        </Modal.Footer>
      </Modal>
    </>
  )
}

export default FirmDashboard
