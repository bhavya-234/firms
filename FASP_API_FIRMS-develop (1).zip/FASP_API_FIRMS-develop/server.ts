import * as dotenv from 'dotenv';
dotenv.config();
import express from 'express';
const app = express();
import { resolve } from 'path'
import cors from 'cors'
import { init as initDb } from './src/config/db'
const PORT = process.env.PORT || 8000;
import router from './src/api/index';
import bodyParser from 'body-parser';
import swaggerJSDoc from 'swagger-jsdoc';
import swaggerUi from "swagger-ui-express";
import swaggerJson from './swagger.json';
import type { ErrorRequestHandler } from "express";
import { logger } from './src/logger';

const publicFolder = resolve(__dirname, './public')
process.env.DIR_ROOT = __dirname;

initDb();
app.use(express.json());
//app.use(bodyParser.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(publicFolder))

const allowedOrigins = ['http://103.174.56.65:3008', 'http://103.174.56.169:8091', 'http://localhost:3008', 'http://10.96.47.103:8091'];
app.use(cors({
    origin: allowedOrigins
}));
app.disable('x-powered-by');
app.disable('etag');
app.use(function (req, res, next) {
    const origin = req.headers.origin;

    if (origin && allowedOrigins.includes(origin)) {

        res.setHeader('Access-Control-Allow-Origin', origin);
    }
    // res.header('Access-Control-Allow-Origin', '*');
    res.header('X-Frame-Options', 'SAMEORIGIN');
    res.header('Access-Control-Allow-Credentials', 'true');
    res.header('Access-Control-Allow-Methods', 'GET,HEAD,PUT,PATCH,POST,DELETE');
    res.header('Access-Control-Expose-Headers', 'Content-Length');
    res.header('Access-Control-Allow-Headers', 'Accept, Authorization, Content-Type, X-Requested-With, Range');
    res.header('X-XSS-Protection', '1; mode=block');
    res.header('X-Content-Type-Options', 'nosniff');
    res.header('Expires', '0');
    res.header('Pragma', 'no-cache');
    res.header('Strict-Transport-Security', 'max-age=63072000; includeSubDomains; preload');
    res.header('Cache-Control', 'private, must-revalidate, max-age=0, no-store, no-cache, must-revalidate, post-check=0, pre-check=0');
    res.header('Content-Security-Policy', `default-src 'self' 'unsafe-inline' 'unsafe-eval' http://103.174.56.65:3008 http://localhost:3008 http://localhost:4000 http://103.174.56.65:4000 http://103.174.56.169:8091 http://10.96.47.103:8091; script-src 'self' 'unsafe-inline'; child-src http://103.174.56.65:3008 http://103.174.56.65:4000 http://103.174.56.169:8091 http://localhost:3008 http://localhost:4000 http://10.96.47.103:8091; img-src * 'self' data: https:;`);
    res.removeHeader("X-Powered-By");
    next();
});

app.use("/api-docs", swaggerUi.serve, swaggerUi.setup(swaggerJson));

app.get("/", (req, res): void => {
    res.send("Hello Typescript with Node.js!")
});

app.use('/api/', router);

const errorHandler: ErrorRequestHandler = (err, req, res, next) => { };
app.use(errorHandler);
app.use((err:any, req:any, res:any, next:any) => {
    try {
        let errorJSON:any = {};
        if (err.statusCode != undefined)
            errorJSON["statusCode"] = err.statusCode;
        else if (err.status != undefined)
            errorJSON["statusCode"] = err.status;
        else
            errorJSON["statusCode"] = 500;

        errorJSON["message"] = err.message;
        errorJSON["type"] = err.type;
        if (err.status === 500 || err.statusCode === 500) {
            errorJSON["status"] = "Internal Server Error";
            res.status(500).send(errorJSON);
        }
        else if (err.status === 400 || err.statusCode === 400) {
            errorJSON["status"] = "Bad Request";
            res.status(400).send(errorJSON);
        }
        else if (err.status === 401 || err.statusCode === 401) {
            errorJSON["status"] = "Unauthorized";
            res.status(401).send(errorJSON);
        }
        else if (err.status === 403 || err.statusCode === 403) {
            errorJSON["status"] = "Forbidden";
            res.status(403).send(errorJSON);
        }
        else if (err.status === 404 || err.statusCode === 404) {
            errorJSON["status"] = "Not Found";
            res.status(404).send(errorJSON);
        }
        else if (err.status === 412 || err.statusCode === 412) {
            errorJSON["status"] = "Precondition Failed";
            res.status(412).send(errorJSON);
        }
    } catch (err) {
        logger.error("error in index :::: ", err);
    }
    let completeUrl = req.protocol + '://' + req.get('host') + req.originalUrl;
    logger.error(`${err.status || err.statusCode} - ${res.statusMessage} - ${err.message} - ${completeUrl} - ${req.method} - ${req.ip}`,);
})
app.listen(PORT, (): void => {
    logger.info(`Server Running here 👉 http://localhost:${PORT}`);
});