import express, { Request, Response } from 'express';
import { PaymentsInformation } from '../../models/index'
import { _paymentResponseUpdate } from '../../services/FirmsService';
import { Firm } from '../../models/index';

export const getPaymentDetails = async (req: Request, res: Response) => {
    try {
        const applicationNumber = req.params.id;
        const paymentDetails = await PaymentsInformation.findOne({applicationNumber: applicationNumber}).sort({createdAt: -1});
        //return res.json(paymentDetails);
        return res.status(200).send({ message: 'Payment Details Fetched Successfully', success: true, data: {paymentDetails: paymentDetails} });
    } catch(error) {
        return res.status(500).json(error);
    }
}

export const paymentResponseDetails = async (req: Request, res: Response) => {
    try {
        const paymentResponseData = {
            applicationNumber: req.body.applicationNumber,
            departmentTransID: req.body.departmentTransID,
            cfmsTransID: req.body.cfmsTransID,
            transactionStatus: req.body.transactionStatus,
            amount: req.body.amount,
            totalAmount: req.body.totalAmount,
            paymentMode: req.body.paymentMode,  
            bankTransID: req.body.bankTransID,
            bankTimeStamp: req.body.bankTimeStamp,
            isUtilized: req.body.isUtilized,
            createdAt: req.body.createdAt
        }

        let status = 'Incomplete';
        let paymentStatus = false;
        if(req.body.transactionStatus == "Success")
        {
            status = 'Not Viewed';
            paymentStatus = true;
        }
        
        console.log("<=====  paymentResponseData  =====>", paymentResponseData);

        const paymentDetails = await _paymentResponseUpdate(req.params.id, paymentResponseData, status, paymentStatus);
        return res.status(200).send({ message: 'Payment Response Details Saved Successfully', success: true, data: {}});
    } catch(error) {
        return res.status(500).json(error);
    }
}

export const confirmDephaseTransaction = async (req: Request, res: Response) => {
    try {
        await PaymentsInformation.findOneAndUpdate(
            { departmentTransID: req.params.id },
            {
                isUtilized: true
            },
        );

        await Firm.findOneAndUpdate(
            { "paymentDetails.departmentTransID": req.params.id },
            {
                "paymentDetails.$.isUtilized": true
            },
        );

        return res.status(200).send({ message: 'Dephase Saved Successfully', success: true, data: {}});
    } catch(error) {
        return res.status(500).json(error);
    }
}

export * as PaymentController from './PaymentController';