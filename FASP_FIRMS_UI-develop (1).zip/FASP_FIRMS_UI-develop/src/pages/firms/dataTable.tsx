import { DateFormator } from "@/GenericFunctions"
import { useRouter } from "next/router"
import { useEffect, useState } from "react"
import { Container, Col, Row, Table } from "react-bootstrap"
import FirmSearch from "./firmSearch"
import CryptoJS from "crypto-js"
import DepartmentTab from "@/components/DepartmentTab"

interface DataTableProps {
  requests?: any
  reqsearchdata?: any
  setReqSearchData?: any
  handleView?: any
  isTableView?: any
  setIsTableView?: any
  isSearchView?: any
  apiResponsetoFirmDataMapper?: any
  setIsError?: any
  setErrorMessage?: any
}

const dataTable = ({
  requests,
  reqsearchdata,
  setReqSearchData,
  handleView,
  isTableView,
  setIsTableView,
  isSearchView,
  apiResponsetoFirmDataMapper,
  setIsError,
  setErrorMessage,
}: DataTableProps) => {
  const [storeData, setStoreData] = useState<any>({})
  const router = useRouter()

  useEffect(() => {
    let data: any = localStorage.getItem("FASPLoginDetails")
    if (data && data != "" && process.env.SECRET_KEY) {
      let bytes = CryptoJS.AES.decrypt(data, process.env.SECRET_KEY)
      data = JSON.parse(bytes.toString(CryptoJS.enc.Utf8))
    }
    setStoreData(data)
  }, [])

  return (
    <>
      <div className="firmReqsList">
      {storeData?.userType!="user"? <DepartmentTab active={1}/>:null}
        {isSearchView ? (
          <FirmSearch
            requests={requests}
            reqsearchdata={reqsearchdata}
            setReqSearchData={setReqSearchData}
            apiResponsetoFirmDataMapper={apiResponsetoFirmDataMapper}
            setIsTableView={setIsTableView}
            setIsError={setIsError}
            setErrorMessage={setErrorMessage}
          />
        ) : (
          <Container />
        )}

        {isTableView ? (
          <Container>
            <Row>
              <Col lg={12} md={12} xs={12}>
                <Table style={{"width":'70%' ,"marginLeft": "auto",
  "marginRight": "auto"}} striped bordered className="tableData listData">
                  <thead>
                    <tr>
                      <th className="text-center">SNo</th>
                      <th className="text-center">Application No</th>
                      <th className="text-center">Applicant Name</th>
                      <th className="text-center">Firm Name</th>
                      <th className="text-center">District Name</th>
                      <th className="text-center">Application Date</th>
                      <th className="text-center">Status</th>
                      <th className="text-center">Remarks</th>
                    </tr>
                  </thead>

                  {reqsearchdata && reqsearchdata.length > 0 ? (
                    <tbody>
                      {reqsearchdata.map((item: any, i: number) => {
                        return (
                          <tr key={i + 1}>
                            {/* <td className="text-center">{i + 1}</td>
                        <td>
                          <a onClick={() => handleView(item.userId)} className="viewData">
                            {item["applicantDetails"].applicationNumber}
                          </a>
                        </td>
                        <td>{item["applicantDetails"].name}</td>
                        <td>{item["firmDetails"].firmName}</td>
                        <td>{item["addressDetails"].district}</td>
                        <td>{item["firmDetails"].firmDurationFrom}</td>
                        <td>{item.status}</td>*/}
                            <td className="text-center">{i + 1}</td>
                            <td>
                              {item["applicantFields"].status == "Incomplete" ? (
                                item["applicantFields"].applicantNumber
                              ) : item["applicantFields"].status != "Forwarded" &&
                                item["applicantFields"].status != "Approved" &&
                                item["applicantFields"].status != "Rejected" &&
                                storeData?.role == "DR" ? (
                                item["applicantFields"].applicantNumber
                              ) : item["applicantFields"].status != "Incomplete" ? (
                                <a
                                  onClick={() => handleView(item["userFields"].userId)}
                                  className="viewData"
                                >
                                  {item["applicantFields"].applicantNumber}
                                </a>
                              ) : null}
                            </td>
                            <td>{item["applicantFields"].applicantName}</td>
                            <td>{item["firmFields"].firmName}</td>
                            <td>{item["firmFields"].district}</td>
                            <td>{DateFormator(item["firmFields"].firmCreatedAt, "dd/mm/yyyy")}</td>
                            <td>{item["applicantFields"].status}</td>
                            {item["processingHistory"].length > 0 ? (
                              <td>
                                {
                                  item["processingHistory"][item.processingHistory.length - 1]
                                    .remarks
                                }
                              </td>
                            ) : (
                              <td />
                            )}
                          </tr>
                        )
                      })}
                    </tbody>
                  ) : (
                    <tbody>
                      <tr>
                        <td colSpan={7}>No Data Found</td>
                      </tr>
                    </tbody>
                  )}
                </Table>
                {storeData?.userType == "user" &&
                  reqsearchdata &&
                  reqsearchdata.length > 0 &&
                  reqsearchdata[0]["applicantFields"].status == "Rejected" &&
                  !reqsearchdata[0]?.processingHistory?.some((x) => x.status == "Approved") && (
                    <Col lg={12} md={12} xs={12}>
                      <div className="d-flex justify-content-between pagesubmitSecTitle mb-3">
                        <div className="ms-2">
                          <h2>
                            <a
                              href="/firms/form1"
                              onClick={() => localStorage.setItem("isResubmission", "true")}
                              style={{ color: "blue" }}
                            >
                              click here
                            </a>{" "}
                            to resubmit form
                          </h2>
                        </div>
                      </div>
                    </Col>
                  )}
              </Col>
            </Row>
          </Container>
        ) : (
          <Container />
        )}
      </div>
    </>
  )
}

export default dataTable
