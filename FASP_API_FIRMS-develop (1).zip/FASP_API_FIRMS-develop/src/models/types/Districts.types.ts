import { Document, Schema } from 'mongoose';

export interface Districts {
    id: string,
    name: string,
    ddoCode: string,
    code: string,
}