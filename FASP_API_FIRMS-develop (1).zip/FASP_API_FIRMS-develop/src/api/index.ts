import express from 'express';
import { UserController } from './controllers/UserController';
import { AuthController } from './controllers/AuthController';
import { FirmController } from './controllers/FirmController';
import { NationalEmblemPreventionController } from './controllers/NationalEmblemsPreventionController';
const router = express.Router();
import { isLogin, isAdmin } from './middleware/auth';

import { validateCreateNewFirm, validateCreateNewSociety, validateCreateFirm, validateLogin, validatedepartmentLogin, validateFirmName, validateCheckUser, validateSocietyName, validateSMS, validatecheckUserAadhar, validateDepartmentChangePassword, validateVerifyOTP, validateRegistrationName}  from './middleware/validations';

import { firmDocsUpload, setAppNumber } from '../utils/functions';
import { Request, Response, NextFunction } from 'express';
import { MasterController } from './controllers/MasterController';
import { PaymentController } from './controllers/PaymentController';

import multer, { FileFilterCallback } from 'multer';
const upload = multer({});

const generateAppNumber = (req: Request, res: Response, next: NextFunction) => {
    setAppNumber();
    next();
}
router.post('/users/createFirm', validateCreateNewFirm(), generateAppNumber, UserController.createFirmSocietyUser);
router.post('/users/createSociety', validateCreateNewSociety(), generateAppNumber, UserController.createFirmSocietyUser);

router.get('/users', isLogin, UserController.getallUsers);
router.get('/users/:id', isLogin, UserController.getUserById);
router.put('/users/update/:id', isLogin, UserController.updateUsers);
router.post('/checkUser', validateCheckUser(), UserController.checkUser);
router.post('/checkUserAadhar', validatecheckUserAadhar(), UserController.checkUserAadhar);

router.post('/login', AuthController.loginUser);
router.post('/departmentLogin', validatedepartmentLogin(), AuthController.loginDepartment);
router.post('/reset', isLogin, AuthController.resetUser);
router.get('/getRefreshToken', isLogin, AuthController.getRefreshToken);
router.post('/department/update', isLogin, isAdmin, upload.single('selfSignedSignature'), UserController.updateDepartmentUser);
router.post('/department/updateDummy', isLogin, isAdmin, UserController.updateDepartmentUserData);
router.get('/department/:id', isLogin, UserController.getDepartmentById);
router.get('/certificateDetails/:id', isLogin, UserController.getDepartmentCertificateDetails);
router.post('/department/changePassword', isLogin, isAdmin, validateDepartmentChangePassword(), AuthController.changePassword);
router.post('/department/dataEntry', isLogin, isAdmin,firmDocsUpload, FirmController.FirmsDataEntry);

//FirmController.
router.post('/firm/check', validateFirmName(), FirmController.checkFirm);
router.post('/firm/update', isLogin, firmDocsUpload, FirmController.updateFirm);
router.put('/firms/update/:id', isLogin, firmDocsUpload, FirmController.updateFirm);

router.put('/firms/sendSMS/:id', isLogin, isAdmin, FirmController.sendSMS);
router.post('/firms/remarks', isLogin, isAdmin, FirmController.processingHistory);
router.get('/firms/download', isLogin, isAdmin, FirmController.downloadFirms);
router.get('/firms/reports', isLogin, isAdmin, FirmController.reports);
router.get('/firms/:id', isLogin,  FirmController.getFirm);
router.get('/firms', isLogin, isAdmin, FirmController.getallFirms);
router.post('/firms/downloads/:id', isLogin, FirmController.downloadsHistory);
router.get('/logout', isLogin, AuthController.Logout);
router.post('/firms/redirectPayment', FirmController.RedirectPayment);
router.post('/firms/redirectcertificate', FirmController.RedirectCertificate);

router.post('/checkAvailability', validateRegistrationName(), NationalEmblemPreventionController.checkAvailability)
router.get('/getDistricts', MasterController.getDistricts);
router.post('/getDistrictsMandals', MasterController.getDistrictsMandals);
router.post('/getDistrictsMandalVillages', MasterController.getDistrictsMandalVillages);
router.post('/getDistrictDdoCode', MasterController.getDistrictDdoCode);

router.get('/getPaymentDetails/:id', isLogin, PaymentController.getPaymentDetails);
router.post('/paymentResponseDetails/:id', isLogin, PaymentController.paymentResponseDetails);
router.post('/confirmDephaseTransaction/:id', isLogin, isAdmin, PaymentController.confirmDephaseTransaction);

router.get('/downloads/:id/:fileName', FirmController.downloadFile);

router.post('/verifyOTP', UserController.verifyOTP)

router.post('/sendSMSMail',UserController.sendSMSMail)
export default router;

