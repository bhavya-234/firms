import express, { Request, Response } from 'express';
import { ObjectId } from 'mongodb'
import { Firm, User, DepartmentUsers } from '../../models/index';
import { getDocs, appNumber } from '../../utils/functions';
import { _checkFirm, _getAllFirms, _getFirm, _createFirm, _updateFirmName, _deleteFirm, _sendSMS, _processingHistoryUpdate, _updateFirmAddress, _updatePartnerAddress, _updateFirmPartner, _updateDocs, _updateFirm, _saveHistory, downloadFirmHistory, _paymentResponseUpdate, _updateUnsetFirm } from '../../services/FirmsService';
import { Firm as FirmType } from '../../models/types/index';
import moment from 'moment';
const multer = require('multer')
import { firmDocsUpload } from '../../utils/functions';
import { userSession } from '../middleware/auth';
import mongoose, { Types } from 'mongoose';

import { downloadUrl } from '../../config/appConfig'
import { createUser, _getAadharNumberByUUID, _getUUIDByAadharNumber } from '../../services/UserService';
import { logger } from '../../logger';
var CryptoJS = require("crypto-js");
const PDFDocument = require("pdfkit-table");
const fs = require('fs');
const Path = require('path');
var xl = require('excel4node');

export const checkFirm = async (req: Request, res: Response) => {
    try {
        const { firmName, district } = req.body;
        console.log("<================  firmName  ================>", firmName);

        const firm = await _checkFirm(firmName, district);

        console.log("<================  firm  ================>", firm);

        if (firm) {
            return res.status(200).send({ message: "Firm already exists!", success: false, data: {} });
        }

        return res.status(200).send({ message: 'The Name is available to register', success: true, data: {} });
    } catch (error) {
        logger.error(`error- ${error}`);
        return res.status(500).send({ message: error, success: false, data: {} });
    }

};

export const changeName = async (req: Request, res: Response) => {
    try {
        const { newFirmName, district, newNameEffectDate } = req.body;
        console.log("<================  newFirmName  ================>", newFirmName);
        console.log("<================  district  ================>", district);
        console.log("<================  req.params.id  ================>", req.body.id);

        const firm = await _checkFirm(newFirmName, district);

        console.log("<================  firm  ================>", firm);

        if (firm) {
            return true;
            //res.status(200).send({ message: "firm already exists!", success: false, data: {} });
        }
        else {
            const payload = {
                firmName: newFirmName,
                district: district,
                newNameEffectDate: newNameEffectDate,
                status: 'Incomplete'
            }

            //firmName: req.body.newFirmName,
            //newNameEffectDate: req.body.newNameEffectDate,

            const firm = await _updateFirm(req.body.id, payload);
            return false;
            //res.status(200).send({ message: 'firm Name changed successfully', success: true, data: {firm: firm} });         
        }

    } catch (error) {
        logger.error(`error- ${error}`);
        return res.status(500).send({ message: error, success: false, data: {} });
    }

};

const isFirmInValid = (req: any, res: any) => {
    return new Promise(function (resolve, reject) {

        const body: any = req.body;
        if (!body['applicantDetails']) {
            resolve({ "success": false, "message": "applicantDetails is not allowed to be empty", "data": {} })

        } else if (!body['applicantDetails']['aadharNumber']) {
            resolve({ "success": false, "message": "applicantDetails.aadharNumber is not allowed to be empty", "data": {} })

        } else if (body['applicantDetails']) {
            const data = body['applicantDetails'];
            const applicantDetails = [
                // { key: 'aadharNumber', reg: /^[2-9]{1}[0-9]{3}[0-9]{4}[0-9]{4}$/ },
                { key: 'age', reg: /^[0-9]{2}$/ },
                { key: 'name', reg: /^[A-Za-z\s]*$/ },
                { key: 'surname', reg: /^[A-Za-z\s]*$/ },
                { key: 'relation', reg: /^[A-Za-z\s]*$/ },
                { key: 'relationType', reg: /^[A-Za-z/\s]*$/ },
                { key: 'gender', reg: /^[A-Za-z\s]*$/ },
                { key: 'role', reg: /^[A-Za-z \s]*$/ },
                // { key: 'doorNo', reg: /[A-Za-z0-9/-]|,/ },
                // { key: 'street', reg: /^[a-zA-Z0-9\s,'-]*$/ },
                { key: 'country', reg: /^[a-zA-Z-\\s\/\-\)\(\`\.\"\'\s]*$/ },
                { key: 'state', reg: /^\s*[a-zA-Z]{1}[0-9a-zA-Z][0-9a-zA-Z '-.=#/]*$/ },
                { key: 'district', reg: /^\s*[a-zA-Z]{1}[0-9a-zA-Z][0-9a-zA-Z '-.=#/]*$/ },
                // { key: 'mandal', reg: /^\s*[a-zA-Z]{1}[0-9a-zA-Z][0-9a-zA-Z '-.=#/]*$/ },
                // { key: 'villageOrCity', reg: /^\s*[a-zA-Z]{1}[0-9a-zA-Z][0-9a-zA-Z '-.=#/]*$/ },
                { key: 'pinCode', reg: /[0-9]/ },
            ];

            applicantDetails.some(obj => {
                if (data[obj.key] && !obj.reg.test(data[obj.key])) {
                    resolve({ "success": false, "message": `${obj.key} format is invalid`, "data": {} })
                    reject('rejected');
                    return true;
                }
            });
        }
        if (body['contactDetails']) {
            console.log('contactDetails................................');
            const data = body['contactDetails'];
            const contactDetails = [
                //{ key: 'landPhoneNumber', reg: /^\d+$/ },
                { key: 'mobileNumber', reg: /^\d{10}$/ },
                { key: 'email', reg: /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/ },
            ];
            contactDetails.forEach(obj => {
                if (data[obj.key] && !obj.reg.test(data[obj.key])) {
                    resolve({ "success": false, "message": `${obj.key} format is invalid`, "data": {} })

                    return true;
                }
            });
        }
        if (body['principalPlaceBusiness']) {
            console.log('principalPlaceBusiness................................');
            const data = body['principalPlaceBusiness'];
            const principalPlaceBusiness = [
                // { key: 'doorNo', reg: /[A-Za-z0-9/-]|,/ },
                // { key: 'street', reg: /^[a-zA-Z0-9\s,'-]*$/ },
                { key: 'state', reg: /^\s*[a-zA-Z]{1}[0-9a-zA-Z][0-9a-zA-Z '-.=#/]*$/ },
                { key: 'district', reg: /^\s*[a-zA-Z]{1}[0-9a-zA-Z][0-9a-zA-Z '-.=#/]*$/ },
                // { key: 'villageOrCity', reg: /^\s*[a-zA-Z]{1}[0-9a-zA-Z][0-9a-zA-Z '-.=#/]*$/ },
                // { key: 'mandal', reg: /^\s*[a-zA-Z]{1}[0-9a-zA-Z][0-9a-zA-Z '-.=#/]*$/ },
                { key: 'pinCode', reg: /[0-9]/ },
                { key: 'branch', reg: /^[a-zA-Z0-9\s,'-]*$/ },
            ];
            principalPlaceBusiness.some(obj => {
                if (data[obj.key] && !obj.reg.test(data[obj.key])) {
                    resolve({ "success": false, "message": `${obj.key} format is invalid`, "data": {} })

                    return true;
                }
            });
        }
        if (body['otherPlaceBusiness']) {
            console.log('otherPlaceBusiness................................');
            const otherPlaceBusinessData = body['otherPlaceBusiness'];
            const otherPlaceBusiness = [
                // { key: 'doorNo', reg: /[A-Za-z0-9/-]|,/ },
                // { key: 'street', reg: /^[a-zA-Z0-9\s,'-]*$/ },
                { key: 'state', reg: /^[a-zA-Z0-9\s,'-]*$/ },
                { key: 'district', reg: /^[a-zA-Z0-9\s,'-]*$/ },
                // { key: 'villageOrCity', reg: /^[a-zA-Z0-9\s,'-]*$/ },
                // { key: 'mandal', reg: /^[a-zA-Z0-9\s,'-]*$/ },
                { key: 'pinCode', reg: /[0-9]/ },
                { key: 'branch', reg: /^[a-zA-Z0-9\s,'-]*$/ },
            ];
            otherPlaceBusinessData.some((data: any) => {
                let isInvalid = false;
                otherPlaceBusiness.some(obj => {
                    if (data[obj.key] && !obj.reg.test(data[obj.key])) {
                        resolve({ "success": false, "message": `${obj.key} format is invalid`, "data": {} })
                        isInvalid = true;

                        return true;
                    }
                });
                return isInvalid;
            });

        }
        if (body['partnerDetails']) {
            console.log('partnerDetails................................');
            const partnerDetailsData = body['partnerDetails'];
            const partnerDetails = [
                // { key: 'aadharNumber', reg: /^[2-9]{1}[0-9]{3}[0-9]{4}[0-9]{4}$/ },
                { key: 'partnerName', reg: /^[A-Za-z\s]*$/ },
                // { key: 'partnerSurname', reg: /^[A-Za-z\s]*$/ },
                { key: 'relation', reg: /^[A-Za-z\s]*$/ },
                { key: 'relationType', reg: /^[A-Za-z/\s]*$/ },
                { key: 'role', reg: /^[A-Za-z \s]*$/ },
                { key: 'age', reg: /^[0-9]{2}$/ },
                //{ key: 'joiningDate', reg: /^(0?[1-9]|[12][0-9]|3[01])[\/\-](0?[1-9]|1[012])[\/\-]\d{4}$/ },
                // { key: 'street', reg: /^[a-zA-Z0-9\s,'-]*$/ },
                { key: 'state', reg: /^[a-zA-Z0-9\s,'-]*$/ },
                { key: 'district', reg: /^[a-zA-Z0-9\s,'-]*$/ },
                // { key: 'villageOrCity', reg: /^[a-zA-Z0-9\s,'-]*$/ },
                // { key: 'mandal', reg: /^[a-zA-Z0-9\s,'-]*$/ },
                { key: 'pinCode', reg: /[0-9]/ },
                { key: 'branch', reg: /^[a-zA-Z0-9\s,'-]*$/ },
            ];
            partnerDetailsData.some((data: any, index: any) => {
                let isInvalid = true;
                partnerDetails.some((obj,) => {
                    const reg = obj.reg.test(data[obj.key]);
                    if (data[obj.key] && (reg === false)) {
                        console.log(`kkkkkkkkk${index}]${obj.key}`, data[obj.key], reg);
                        resolve({ "success": false, "message": `partnerDetails[${index}]${obj.key} format is invalid`, "data": {} })
                        isInvalid = false;

                        return true;
                    }
                });
                return isInvalid;
            });
        }

        console.log('else................................');

        // const booleanArray = ['isFirmNameChange', 'isPrincipaladdressChange', 'isOtherAddressChange', 'isPartnerPermanentAddressChange', 'isNewPartnerAdded', 'isPartnerDeleted', 'isPartnerReplaced'];
        // booleanArray.some(key=>{
        //     if((body[key] !== true || body[key] !== false)){
        //         console.log('dddddddd', typeof body[key]);
        //         resolve({"success": false, "message": `${key} format is invalid`, "data": {}})
        //    
        //         return true;
        //     }
        // });
        // const arr = [
        //{ key: 'firmDurationFrom', reg: /^(0?[1-9]|[12][0-9]|3[01])[\/\-](0?[1-9]|1[012])[\/\-]\d{4}$/ },
        //{ key: 'firmDurationTo', reg: /^(0?[1-9]|[12][0-9]|3[01])[\/\-](0?[1-9]|1[012])[\/\-]\d{4}$/ },
        //     { key: 'industryType', reg: /^[A-Za-z/\s]*$/ },
        //     { key: 'bussinessType', reg: /^[A-Za-z/\s]*$/ }];
        // arr.some((obj: any) => {
        //     if (Object.hasOwnProperty.bind(body)(obj.key) && !obj.reg.test(body[obj.key])) {
        //         resolve({ "success": false, "message": `${obj.key} format is invalid`, "data": {} })

        //         return true;
        //     }
        // });
        resolve(false);
    });
}

export const updateFirm = async (req: Request, res: Response) => {
    try {
        if (req.body.formType === 'form-1') {

            let data = await isFirmInValid(req, res);
            if (data) {
                return res.status(400).send(data);
            }
        }
        //console.log("<====   userSession  =======>", userSession);
        console.log("<====   Request  =======>", req.body);

        let appId;
        if (req.body.id)
            appId = req.body.id;
        else if (req.params.id)
            appId = req.params.id;

        await _saveHistory(req.body.id);
        if (req.body.isFirmNameChange == "true" && req.body.newFirmName) {
            const firm = await changeName(req, res);

            console.log("<================  firm  ================>", firm);

            if (firm) {
                return res.status(200).send({ message: "Firm already exists!", success: false, data: {} });
            }
        }
        else if (req.body.firmDissolved == "true" && req.body.firmDissolved) {
            const payload = {
                firmDissolved: true,
                status: 'Incomplete'
            }
            const firm = await _updateFirm(req.body.id, payload);
            let applicantDetails = firm?.applicantDetails;
            let firmPartners = firm?.firmPartners;
            if (applicantDetails?.aadharNumber && applicantDetails?.aadharNumber?.toString() != null) {
                const resp = await _getAadharNumberByUUID(applicantDetails.aadharNumber.toString())
                if (resp.data?.status == "Success") {
                    applicantDetails.aadharNumber = resp.data.UID
                }
                else {
                    return res.status(500).send({ message: 'Aadhaar service is not working. Please try after sometime', success: false, data: {} });
                }
            }
            if (firmPartners != undefined && firmPartners?.length > 0) {
                for await (let pd of firmPartners) {
                    if (pd.aadharNumber?.toString() != "") {
                        const resp = await _getAadharNumberByUUID(pd.aadharNumber.toString())
                        if (resp.data?.status == "Success") {
                            pd.aadharNumber = resp.data.UID
                        }
                        else {
                            return res.status(500).send({ message: 'Aadhaar service is not working. Please try after sometime', success: false, data: {} });
                        }
                    }
                }
            }
            return res.status(200).send({ message: 'Firm dissolved successfully', success: true, data: { firm: firm } });
        }


        if (req.body.formType === 'form-1') {
            const files = req.files as { [fieldname: string]: Express.Multer.File[] };
            const attachments = getDocs(files);
            if (attachments.length < 3) {
                return res.status(500).send({ message: `Please upload valid file attachment or only PDF type should be accepted`, success: false, data: {} });
            }
            const firmDetails = req.body.firmDetails;
            req.body.firmDurationFrom = req.body.firmDurationFrom;// ? moment(req.body.firmDurationFrom, 'DD/MM/YYYY').format('YYYY-MM-DD') : '';
            req.body.firmDurationTo = req.body.firmDurationTo; //moment(req.body.firmDurationTo, 'DD/MM/YYYY').format('YYYY-MM-DD');
            let partnerDetails = req.body.partnerDetails;
            if (partnerDetails && partnerDetails.length > 0) {
                for await (let pd of partnerDetails) {
                    if (pd.aadharNumber) {
                        const resp = await _getUUIDByAadharNumber(pd.aadharNumber.toString())
                        if (resp.data?.status == "Success") {
                            pd.aadharNumber = resp.data.UUID
                        }
                        else {
                            return res.status(500).send({ message: 'Aadhaar service is not working. Please try after sometime', success: false, data: {} });
                        }
                    }
                }
            }

            let processingHistory = req.body.processingHistory;
            if (processingHistory && processingHistory.length) {
                processingHistory = processingHistory.map((ph: any) => {
                    if (ph.applicationTakenDate) {
                        ph.applicationTakenDate = moment(ph.applicationTakenDate, 'DD/MM/YYYY').format('YYYY-MM-DD');
                    }
                    if (ph.applicationProcessedDate) {
                        ph.applicationProcessedDate = moment(ph.applicationProcessedDate, 'DD/MM/YYYY').format('YYYY-MM-DD');
                    }
                    return ph;
                });
            }
            let applicationDetails = req.body.applicantDetails;
            if (applicationDetails?.aadharNumber && applicationDetails?.aadharNumber?.toString() != '') {
                const resp = await _getUUIDByAadharNumber(applicationDetails.aadharNumber.toString())
                if (resp.data?.status == "Success") {
                    applicationDetails.aadharNumber = resp.data.UUID
                }
                else {
                    return res.status(500).send({ message: 'Aadhaar service is not working. Please try after sometime', success: false, data: {} });
                }
            }
            applicationDetails.applicationNumber = appNumber;
            const firmUnset: any = {
                isPartnerReplaced: false,
                isNewPartnerAdded: false,
                isPartnerDeleted: false,
                firmDissolved: false,
                isOtherAddressChange: false,
                isPartnerPermanentAddressChange: false,
                isFirmNameChange: false,
                isPrincipaladdressChange: false,
            }
            await _updateUnsetFirm(appId, firmUnset)
            const firmPayload: any = {
                applicantDetails: applicationDetails,
                contactDetails: req.body.contactDetails,
                firmDurationFrom: req.body.firmDurationFrom,
                firmDurationTo: req.body.firmDurationTo,
                atWill: req.body.atWill,
                industryType: req.body.industryType,
                bussinessType: req.body.bussinessType,
                principalPlaceBusiness: req.body.principalPlaceBusiness,
                otherPlaceBusiness: req.body.otherPlaceBusiness,
                firmPartners: partnerDetails,
                documentAttached: attachments,
                processingHistory: [],
                messageToApplicant: [],
                status: 'Incomplete',
                isdownload: false,
                firmStatus: 'Pending',
                paymentStatus: false,
                isResubmission: false,
                isPartnerReplaced: req.body.isPartnerReplaced == "true" ? true : false,
                isNewPartnerAdded: req.body.isNewPartnerAdded == "true" ? true : false,
                isPartnerDeleted: req.body.isPartnerDeleted == "true" ? true : false,
                firmDissolved: req.body.firmDissolved == "true" ? true : false,
                isOtherAddressChange: req.body.isOtherAddressChange == "true" ? true : false,
                isPartnerPermanentAddressChange: req.body.isPartnerPermanentAddressChange == "true" ? true : false,
                isFirmNameChange: req.body.isFirmNameChange == "true" ? true : false,
                isPrincipaladdressChange: req.body.isPrincipaladdressChange == "true" ? true : false,
                updatedBy: userSession.email,
                
                version:process.env.E_VERSION,
            }

            if (req.body.isResubmission) {
                firmPayload.applicationNumber = 'FRA' + Date.now() + ((Math.random() * 100000).toFixed());
                firmPayload.isResubmission = true;
            }

            let newFirm = await _updateFirm(appId, firmPayload)


            //const newFirmPartners = await _createFirmPartners(partnerDetails)

            let applicantDetailses = newFirm?.applicantDetails;
            let firmPartnerses = newFirm?.firmPartners;
            if (applicantDetailses?.aadharNumber && applicantDetailses?.aadharNumber?.toString() != '') {
                const resp = await _getAadharNumberByUUID(applicantDetailses.aadharNumber.toString())
                if (resp.data?.status == "Success") {
                    applicantDetailses.aadharNumber = resp.data.UID
                }
                else {
                    return res.status(500).send({ message: 'Aadhaar service is not working. Please try after sometime', success: false, data: {} });
                }
            }
            if (firmPartnerses != undefined && firmPartnerses?.length > 0) {
                for await (let pd of firmPartnerses) {
                    if (pd.aadharNumber?.toString() != "") {
                        const resp = await _getAadharNumberByUUID(pd.aadharNumber.toString())
                        if (resp.data?.status == "Success") {
                            pd.aadharNumber = resp.data.UID
                        }
                        else {
                            return res.status(500).send({ message: 'Aadhaar service is not working. Please try after sometime', success: false, data: {} });
                        }
                    }
                }
            }
            return res.status(200).send({ message: 'Update Firm successfully done', success: true, data: { firm: { newFirm } } });
        }
        else if (req.body.formType === 'payment') {
            await _paymentResponseUpdate(appId, {}, "Not Viewed", true)
        }
    } catch (error: any) {
        logger.error(`error- ${error}`);
        if (error && error.name == "CastError") {
            return res.status(500).send({ message: `Please provide correct value for ${error.path}`, success: false, data: {} });
        }
        else {
            return res.status(500).send({ message: error, success: false, data: {} });
        }
    }
};

export const sendSMS = async (req: Request, res: Response) => {
    try {
        const { id } = req.params;

        const firm = await Firm.findById({ _id: id })
        if (!firm) {
            return res.status(404).send({ message: 'Firm does not exits!', success: false, data: {} });
        }
        const user = await User.findById({ _id: firm.userId })
        if (!user) {
            return res.status(404).send({ message: 'User does not exits!', success: false, data: {} });
        }

        const smsMessage = {
            number: user.mobileNumber,
            message: req.body.message,
            sentDate: moment().format(),
        }

        const result = await _sendSMS(id, userSession._id, smsMessage);
        return res.status(200).send({ message: 'SMS Sent successfully', success: true, data: {} });

    }
    catch (error) {
        logger.error(`error- ${error}`);
        return res.status(500).send({ message: error, success: false, data: {} });
    }
}
/*
export const processingHistory = async (req: Request, res: Response) => {
    try {
        const { id } = req.params;

        const firm = await Firm.findById({ _id: id })
        if (!firm) {
            return res.status(404).send({ message: 'Firm does not exits!', success: false, data: {} });
        }

        const remarksData = {
            designation: userSession.userName,
            status: "Forwarded By DLF",
            remarks: req.body.remarks,
            attachements: [],
            applicationTakenDate: firm.createdAt,
            applicationProcessedDate: moment().format(),
        }
        
        const result = await _processingHistoryUpdate(id, userSession._id, remarksData);
        return res.status(200).send({ message: 'Remarks Saved successfully', success: true, data: { } });

    }
    catch (error) {
        console.log('error-', error);
        return res.status(500).send({ message: error, success: false, data: {} });
    }

}
*/

export const RedirectPayment = async (req: Request, res: Response) => {

    res.writeHead(301, {

        'Location': `${process.env.REDIRECTURL}`

    }).end();
}
export const RedirectCertificate = async (req: Request, res: Response) => {

    res.writeHead(301, {

        'Location': `${process.env.REDIRECTCERTIFICATEURL}`

    }).end();
}
export const FirmsDataEntry = async (req: Request, res: Response) => {
    try {

        const files = req.files as { [fieldname: string]: Express.Multer.File[] };
        const attachments = getDocs(files);
       attachments.forEach((x: any) => { x.destination = `./uploads/0`, x.path = `./uploads/0/${x.originalname}` })
     
       
            const applicationNumber = 'FRA' + Date.now() + ((Math.random() * 100000).toFixed());
            let registrationNumber = req.body.registrationNumber;
            let registrationYear = req.body.registrationYear;
            const firmData: any = await Firm.findOne({ registrationYear: registrationYear, district: userSession.district }, { registrationNumber: 1, registrationYear: 1, district: 1 }).sort({ registrationNumber: -1 })
            if (firmData && firmData.registrationNumber > 0 && firmData.registrationYear == registrationYear && firmData.district == userSession.district) {
                registrationNumber = firmData.registrationNumber + 1;
            }
         
            const reqBodyFirm = { ...req.body, applicationNumber: applicationNumber, registrationNumber: registrationNumber, paymentStatus: true, approvedRejectedById: userSession._id, deptUpdatedBy: userSession._id, documentAttached: attachments }
            const firm = await _createFirm(reqBodyFirm);
            if (firm) {
                await _saveHistory(firm._id);
                const remarksData = {
                    designation: userSession.userName,
                    status: req.body.status,
                    remarks: "",
                    attachements: [],
                    applicationTakenDate: req.body.applicationProcessedDate,
                    applicationProcessedDate: req.body.applicationProcessedDate,
                }
                const result = await _processingHistoryUpdate(firm._id, userSession._id, remarksData);
                return res.status(200).send({
                    success: true,
                    message: 'Firm details saved successfully',
                    data: {}
                });
            }
            else {
                return res.status(200).send({
                    success: false,
                    message: 'Internal error',
                    data: {}
                });
            }
        // }
    } catch (error) {
        // logger.error(`error- ${error}`);
        return res.status(500).send({ message: error, success: false, data: {} });
    }
}
export const processingHistory = async (req: Request, res: Response) => {
    try {
        if (!req.body.remark) {
            return res.status(404).send({ message: 'Remark data is not allowed to be empty', success: false, data: {} });
        }
        let bytesreq = CryptoJS.AES.decrypt(req.body.remark, process.env.SECRET_KEY);
        let remarkData = JSON.parse(bytesreq.toString(CryptoJS.enc.Utf8));
        let firmId = remarkData.id;
        const reg = /^[A-Za-z\s]*$/;
        if (!remarkData.remarks) {
            return res.status(404).send({ message: 'Remarks is not allowed to be empty', success: false, data: {} });
        } else if (remarkData.remarks && !reg.test(remarkData.remarks)) {
            return res.status(404).send({ message: 'Remarks format is invalid!', success: false, data: {} });
        } else if (req.body.status && !reg.test(req.body.status)) {
            return res.status(404).send({ message: 'Status format is invalid!', success: false, data: {} });
        }
        const firm: any = await Firm.findById({ _id: firmId })
        if (!firm) {
            return res.status(404).send({ message: 'Firm does not exits!', success: false, data: {} });
        }
        if (remarkData.status == "Approved" && firm.status == "Rejected") {
            return res.status(404).send({ message: `Firm is already rejected you cannot approve it`, success: false, data: {} });
        }
        else if (remarkData.status == "Rejected" && firm.status == "Approved") {
            return res.status(404).send({ message: `Firm is already approved you cannot reject it`, success: false, data: {} });
        }
        else if ((!remarkData.status || remarkData.status == "Forwarded") && (firm.status == "Approved" || firm.status == "Rejected")) {
            return res.status(404).send({ message: `Firm is already approved you cannot forward it`, success: false, data: {} });
        }
        else if (userSession.role == "DR" && remarkData.status == "Forwarded") {
            return res.status(404).send({ message: `Firm status cannot be changed to forward`, success: false, data: {} });
        }
        else if (userSession.role != "DR" && (remarkData.status == "Approved" || remarkData.status == "Rejected")) {
            return res.status(404).send({ message: `Firm status cannot be changed to approved/rejected`, success: false, data: {} });
        }
        else if (firm.district?.toLowerCase() != userSession.district?.toLowerCase()) {
            return res.status(404).send({ message: `Firm status cannot be updated`, success: false, data: {} });
        }
        let status = "Forwarded By DLF";
        let applicationStatus = 'Forwarded';
        let firmStatus = 'Pending';
        if (remarkData.status) {
            status = remarkData.status;
            applicationStatus = remarkData.status;
            let payload;
            if (remarkData.status == "Approved") {
                //firmStatus = 'Active';


                let registrationNumber: any = 1;
                let registrationYear: any = moment().format('YYYY');
                if ((!firm.registrationNumber || firm.registrationNumber <= 0) && firm.district == userSession.district) {
                    let registrationYear = moment().format('YYYY');
                    const firmData: any = await Firm.findOne({ registrationYear: registrationYear, district: userSession.district }, { registrationNumber: 1, registrationYear: 1, district: 1 }).sort({ registrationNumber: -1 })
                    console.log('<============= firmData =============>', firmData);


                    if (firmData && firmData.registrationNumber > 0 && firmData.registrationYear == registrationYear && firmData.district == userSession.district) {
                        registrationNumber = firmData.registrationNumber + 1;
                    }
                    console.log('<============= registrationNumber =============>', registrationNumber);
                }
                else {
                    registrationNumber = firm.registrationNumber ? firm.registrationNumber : '';
                    registrationYear = firm.registrationYear ? firm.registrationYear : '';
                }

                payload = {
                    status: 'Approved',
                    firmStatus: 'Active',
                    isNameChanged: 'false',
                    isMemberChanged: 'false',
                    registrationNumber: registrationNumber,
                    registrationYear: registrationYear,
                    approvedRejectedById: userSession._id,
                }

            }
            else {
                payload = {
                    status: status,
                    firmStatus: 'Pending'
                }
            }

            await _updateFirm(firmId, payload);
        }
        else {
            let payload = {
                status: applicationStatus,
                firmStatus: 'Pending',
            }
            await _updateFirm(firmId, payload);
        }

        const remarksData = {
            designation: userSession.userName,
            status: status,
            remarks: remarkData.remarks,
            attachements: [],
            applicationTakenDate: moment(firm.createdAt).format('YYYY-MM-DD'),
            applicationProcessedDate: moment().format(),
        }

        console.log("<===========  remarksData  ==========>", remarksData);

        const result = await _processingHistoryUpdate(firmId, userSession._id, remarksData);
        return res.status(200).send({ message: 'Remarks Saved successfully', success: true, data: {} });

    }
    catch (error) {
        logger.error(`error- ${error}`);
        return res.status(500).send({ message: error, success: false, data: {} });
    }

};

export const makeExcel = async (firms: any) => {
    const path = Path.join(__dirname, "../../../downloads/firms");
    if (!fs.existsSync(path)) {
        fs.mkdirSync(path);
    }

    var wb = new xl.Workbook();
    var ws = wb.addWorksheet('Sheet 1');
    var headerStyle = wb.createStyle({
        font: {
            color: '#000000',
            size: 14,
            bold: true
        }
    });
    var rowsStyle = wb.createStyle({
        font: {
            color: '#000000',
            size: 12
        }
    });

    ws.cell(1, 1).string("SNo").style(headerStyle);
    ws.cell(1, 2).string("Application No").style(headerStyle);
    ws.cell(1, 3).string("Firm Name").style(headerStyle);
    ws.cell(1, 4).string("District Name").style(headerStyle);
    ws.cell(1, 5).string("Application Date").style(headerStyle);
    ws.cell(1, 6).string("Status").style(headerStyle);

    for (let i = 0; firms && i < firms.length; i++) {
        ws.cell(i + 2, 1).number(i + 1).style(rowsStyle);
        ws.cell(i + 2, 2).string(firms[i].applicationNumber).style(rowsStyle);
        ws.cell(i + 2, 3).string(firms[i].firmName).style(rowsStyle);
        ws.cell(i + 2, 4).string(firms[i].district).style(rowsStyle);
        ws.cell(i + 2, 5).string(firms[i].createdAt.toString()).style(rowsStyle);
        ws.cell(i + 2, 6).string(firms[i].status).style(rowsStyle);
    }

    const fileName = "Firms_" + moment().format('YYYYMMDDhmmss') + ".xlsx";

    wb.write("downloads/firms/" + fileName);
    return fileName;


}

export const makePdf = async (societies: any) => {
    let doc;
    try {
        //let Url = "http://localhost/pdfs";
        const path = Path.join(__dirname, "../../../downloads/firms");
        if (!fs.existsSync(path)) {
            fs.mkdirSync(path);
        }

        // const doc = new PDFDocument({size: 'A4'});
        doc = new PDFDocument({ size: 'A4' });
        const fileNameValue = "Firms_" + moment().format('YYYYMMDDhmmss');

        console.log("<=== fileNameValue ===>", fileNameValue);

        doc.pipe(fs.createWriteStream(`${path}/${fileNameValue}.pdf`));
        let rowsValues = [];
        for (let i = 0; societies && i < societies.length; i++) {
            let indRow = [];
            indRow.push(i + 1);
            indRow.push(societies[i].applicationNumber)
            indRow.push(societies[i].FirmName)
            indRow.push(societies[i].district)
            indRow.push(societies[i].createdAt.toString())
            indRow.push(societies[i].status)
            rowsValues.push(indRow)
        }

        const table = {
            title: "Firms",
            headers: ["SNo", "Application No", "Firm Name", "District Name", "Application Date", "Status"],
            rows: rowsValues,
        };
        console.log()
        await doc.table(table, {
            height: 300,
            columnsSize: [25, 125, 150, 50, 125, 50],
            boundary: true
        });
        doc.end();
        //await new Promise(res => setTimeout(res, 1000));
        //const bitmap = fs.readFileSync(`${path}/${fileNameValue}.pdf`);
        return fileNameValue + ".pdf";
    } catch (ex) {
        if (doc != undefined && doc != null)
            doc.end();
        logger.error(`error- ${ex}`);
        return null;
    }
}

export const downloadFirms = async (req: Request, res: Response) => {
    try {

        if (userSession.district) {
            const { downloadType } = req.query;

            console.log("<=== downloadType ===>", downloadType);

            const { firms, totalCount } = await _getAllFirms(req, userSession.district);

            let downloadLink;
            if (downloadType == 'pdf') {
                downloadLink = await makePdf(firms);
            }
            else if (downloadType == 'xls') {
                downloadLink = await makeExcel(firms);
            }
            else {
                return res.status(200).send({ message: 'downloadType not found', success: false, data: {} });
            }

            let fullDownloadUrl = `${downloadUrl}/firms/${downloadLink}`;
            return res.status(200).send({ message: 'Download successfully done', success: true, data: { downloadUrl: fullDownloadUrl } });
        }
        else {
            return res.status(401).send({ success: false, message: "Invalid User", data: {} });
        }

    } catch (error) {
        logger.error(`error- ${error}`);
        return res.status(500).send({ message: error, success: false, data: {} });
    }

}

export const getallFirms = async (req: Request, res: Response) => {
    try {

        if (userSession.district) {
            const { firms, totalCount } = await _getAllFirms(req, userSession.district);
            //await makePdf(dasocieties);
            // await makeExcel(dasocieties);
            const data = CryptoJS.AES.encrypt(JSON.stringify({ message: 'Get Firms details successfully done', success: true, data: { firms, totalCount } }), process.env.SECRET_KEY).toString();

            return res.status(200).send(data);
        }
        else {
            const data = CryptoJS.AES.encrypt(JSON.stringify({ success: false, message: "Invalid User", data: {} }));
            return res.status(401).send(data);
        }

    } catch (error) {
        logger.error(`error- ${error}`);
        return res.status(500).send({ message: error, success: false, data: {} });
    }

}
/*
export const getallFirms = async (req: Request, res: Response) => {
    try {
        const sort = '_id';
        const perPage: any = req.query ? req.query.perPage : 10;
        const page: any = req.query ? req.query.page : 1;
        const skip: any = (parseInt(page) - 1) * parseInt(perPage);
        let fromDate:any = req.query.from ? req.query.from : '';
        if(fromDate) {
            fromDate = moment(fromDate, 'DD-MM-YYYY').format('YYYY-MM-DD');
        }
        
        let toDate:any = req.query.to ? req.query.to : '';
        if(toDate) {
            toDate = moment(toDate, 'DD/MM/YYYY').format('YYYY-MM-DD');
        } else {
            toDate = moment().format('YYYY-MM-DD');
        }
        
        const status = req.query.status;
        const limit = parseInt(perPage);
        
        
        const filterAndCond = [];
        const filerOrCond = [];
        
        if(fromDate && toDate) {
            filterAndCond.push({ createdAt: { $gte: new Date(fromDate), $lte: new Date(toDate) } } );
        } 
        if(status) {
            filerOrCond.push({"status": { $regex: status, $options: "i" }});
 
        }
        
        const filterObject:any = {};
        if(filterAndCond.length) {
            filterObject['$and'] = filterAndCond;
        }
        if(filerOrCond.length) {
            filterObject['$or'] = filerOrCond;
        }
        const { firms, totalCount } = await _getAllFirms(filterObject, skip, limit);
 
        return res.status(200).send({ message: 'Get Firms details successfully done', success: true, data: { firms, totalCount } });
    } catch (error) {
        console.log(error)
        return res.status(500).send({ message: error, success: false, data: {} });
    }
 
}
*/
export const getFirm = async (req: Request, res: Response) => {
    try {

        const id = Buffer.from(req.params.id, 'base64').toString();
        if (!ObjectId.isValid(id)) {
            return res.status(404).send({ message: `Firm id not found`, success: false, data: {} });
        }
        let firm: any = await _getFirm(id);

        if (firm.district != userSession.district) {
            return res.status(404).send({ message: `Firm details are not accessable for this user`, success: false, data: {} });
        }
        if (firm?.status === 'Not Viewed') {
            if (userSession.role == 'DLF' || userSession.role == 'DR') {
                const payload = {
                    status: 'Open'
                }
                firm = await _updateFirm(firm._id, payload);
            }
        }

        if (!firm) {
            return res.status(404).send({ message: `Firm details are not found for ${id}`, success: false, data: {} });
        }
        let applicantDetails = firm.applicantDetails;
        let firmPartners = firm.firmPartners;
        if (applicantDetails?.aadharNumber && applicantDetails?.aadharNumber?.toString() != null) {
            const resp = await _getAadharNumberByUUID(applicantDetails.aadharNumber.toString())
            if (resp.data?.status == "Success") {
                applicantDetails.aadharNumber = resp.data.UID
            }
            else {
                return res.status(500).send({ message: 'Aadhaar service is not working. Please try after sometime', success: false, data: {} });
            }
        }
        if (firmPartners?.length > 0) {
            for await (let pd of firmPartners) {
                if (pd.aadharNumber?.toString() != "") {
                    const resp = await _getAadharNumberByUUID(pd.aadharNumber.toString())
                    if (resp.data?.status == "Success") {
                        pd.aadharNumber = resp.data.UID
                    }
                    else {
                        return res.status(500).send({ message: 'Aadhaar service is not working. Please try after sometime', success: false, data: {} });
                    }
                }
            }
        }

        //firm={...firm,firmPartners:partners,applicantDetails:applicantDetails}
        const data = CryptoJS.AES.encrypt(JSON.stringify({ message: 'Get Firm details successfully done', success: true, data: { firm } }), process.env.SECRET_KEY).toString();
        return res.status(200).send(data);
    } catch (error) {
        logger.error(`error- ${error}`);
        return res.status(500).send({ message: error, success: false, data: {} });
    }

};

export const downloadFile = async (req: Request, res: Response) => {

    try {
        const { id, fileName } = req.params;


        console.log("<==== process.env.DIR_ROOT ====>", process.env.DIR_ROOT);
        //console.log("<==== id ====>", id);
        //console.log("<==== fileName ====>", fileName);
        //console.log("<==== __dirname ====>", __dirname);

        const path = process.env.DIR_ROOT + `/uploads/${id}/${fileName}`;

        if (fs.existsSync(path)) {

            console.log("<==== path ====>", path);

            const file = fs.createReadStream(path)
            var stat = fs.statSync(path);
            const filename = fileName;//(new Date()).toISOString()
            res.setHeader('Content-Length', stat.size);
            res.setHeader('Content-Type', 'application/pdf');
            res.setHeader('Content-Disposition', 'attachment; filename="' + filename + '"');
            file.pipe(res);
        }
        else {
            return res.status(500).send();
        }

    }
    catch (error) {
        logger.error(`error- ${error}`);
        return res.status(500).send({ message: error, success: false, data: {} });
    }
}

export const downloadsHistory = async (req: Request, res: Response) => {
    try {
        const payload = {
            amount: req.body.amount,
            downloadDate: moment().format(),
        }

        await downloadFirmHistory(req.params.id, payload, req.body.appId);

        return res.status(200).send({ message: 'Downloads saved successfully', success: true, data: {} });

    }
    catch (error) {
        logger.error(`error- ${error}`);
        return res.status(500).send({ message: error, success: false, data: {} });
    }
}

export const reports = async (req: Request, res: Response) => {
    try {

        let approved = 0;
        let rejected = 0;
        let notViewed = 0;
        let forwarded = 0;
        let open = 0;

        const firms = await Firm.find({ district: userSession.district, status: { $ne: 'Incomplete' } }, { status: 1 })

        firms.forEach(firm => {
            if (firm.status == 'Approved')
                approved += 1;
            if (firm.status == 'Rejected')
                rejected += 1;
            if (firm.status == 'Not Viewed')
                notViewed += 1;
            if (firm.status == 'Forwarded')
                forwarded += 1;
            if (firm.status == 'Open')
                open += 1;

            console.log("<================  firm  ================>", firm);
        });

        console.log("<================  approved  ================>", approved);
        console.log("<================  rejected  ================>", rejected);
        console.log("<================  notViewed  ================>", notViewed);
        console.log("<================  forwarded  ================>", forwarded);
        console.log("<================  open  ================>", open);

        const reports = {
            district: userSession.district,
            approved: approved,
            rejected: rejected,
            notViewed: notViewed,
            forwarded: forwarded,
            open: open
        }

        return res.status(200).send({ message: 'Reports generated successfully', success: true, data: { reports } });

    }
    catch (error) {
        logger.error(`error- ${error}`);
        return res.status(500).send({ message: error, success: false, data: {} });
    }
}


/*
export const createFirm = async (req: Request, res: Response) => {
    try {
 
        //console.log("<====   userSession  =======>", userSession);
        //console.log("<====   Request  =======>", req.body);
 
        const files = req.files as { [fieldname: string]: Express.Multer.File[] };
        const attachments = getDocs(files);
        if(attachments.length < 5) {
            return res.status(500).send({ message: `Please upload valid file attachment or only .pdf type should be accepted`, success: false, data: {} });
        }
        const firmDetails = req.body.firmDetails;
        firmDetails.firmDurationFrom = firmDetails.firmDurationFrom ? moment(firmDetails.firmDurationFrom, 'DD/MM/YYYY').format('YYYY-MM-DD') : '';
        firmDetails.firmDurationTo = moment(firmDetails.firmDurationTo, 'DD/MM/YYYY').format('YYYY-MM-DD');
        let partnerDetails = req.body.partnerDetails;
        if(partnerDetails && partnerDetails.length) {
            partnerDetails = partnerDetails.map((pd: any) => {
                if(pd.joiningDate) {
                    pd.joiningDate = moment(pd.joiningDate, 'DD/MM/YYYY').format('YYYY-MM-DD')
                }
                return pd;
            });
        }
        
        let processingHistory = req.body.processingHistory;
        if(processingHistory && processingHistory.length) {
            processingHistory = processingHistory.map((ph: any) => {
                if(ph.applicationTakenDate) {
                    ph.applicationTakenDate = moment(ph.applicationTakenDate, 'DD/MM/YYYY').format('YYYY-MM-DD');
                }
                if(ph.applicationProcessedDate) {
                    ph.applicationProcessedDate = moment(ph.applicationProcessedDate, 'DD/MM/YYYY').format('YYYY-MM-DD');
                }
                return ph;
            });
        }
        const applicationDetails = req.body.applicantDetails;
        applicationDetails.applicationNumber = appNumber;
        const firmPayload: Firm = {
            userId: userSession._id,
            applicantDetails: applicationDetails,
            addressDetails: req.body.addressDetails,
            contactDetails: req.body.contactDetails,
            firmDetails: firmDetails,
            principalPlaceBusiness: req.body.principalPlaceBusiness,
            documentAttached: attachments,
            processingHistory: [],
            messageToApplicant: []
        }
        let newFirm = await _createFirm(firmPayload)
 
        partnerDetails = partnerDetails.map((pd: any) => {
            pd.firmId = newFirm._id;
            return pd;
        });        
 
        const newFirmPartners = await _createFirmPartners(partnerDetails)
 
        return res.status(200).send({ message: 'Create Firm successfully done', success: true, data: { firm: {newFirm, partnerDetails: newFirmPartners} } });
    } catch (error) {
        console.log(error);
        return res.status(500).send({ message: error, success: false, data: {} });
    }
 
}
 
export const updateFirms = async (req: Request, res: Response) => {
    try {
        const { id } = req.params;
        const firm = await Firm.findById({ _id: id })
        if (!firm) {
            return res.status(404).send({ message: 'Firm does not exits!', success: false, data: {} });
        }
        const files = req.files as { [fieldname: string]: Express.Multer.File[] };
        const attachments = getDocs(files);
        const firmUpdatePayload: Firm = {
            userId: userSession._id,
            applicantDetails: req.body.applicantDetails,
            addressDetails: req.body.addressDetails,
            contactDetails: req.body.contactDetails,
            firmDetails: req.body.firmDetails,
            principalPlaceBusiness: req.body.principalPlaceBusiness,
            documentAttached: attachments,
        }
        const result = await _updateFirm(id, firmUpdatePayload);
        return res.status(200).send({ message: 'Update Firm successfully done', success: true, data: { firm: result } });
 
    }
    catch (error) {
        console.log('error-', error);
        return res.status(500).send({ message: error, success: false, data: {} });
    }
 
}
 
export const deleteFirm = async (req: Request, res: Response) => {
    try {
        const { id } = req.params;
        const result = await _deleteFirm(id);
        return res.status(200).send({ message: 'Delete Firm successfully done', success: true, data: { firm: result } });
    } catch (error) {
        return res.status(500).send({ message: error, success: false, data: {} });
    }
 
}
*/

export * as FirmController from './FirmController';


function ISODate(firmDurationFrom: any) {
    throw new Error('Function not implemented.');
}

