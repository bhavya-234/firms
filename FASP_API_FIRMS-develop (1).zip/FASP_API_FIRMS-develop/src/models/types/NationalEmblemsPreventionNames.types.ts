import { Document, Schema } from 'mongoose';

export interface NationalEmblemsPreventionNames {
    name: String
}