import React, { useState, useEffect } from "react"
import Head from "next/head"
import { Container, Col, Row, Button, Table } from "react-bootstrap"
import instance from "@/redux/api"
import JsBarcode from "jsbarcode"
import { downloadFirmCertificate, getDeptSignature, getFirmDetails } from "@/axios"
import api from "@/pages/api/api"
import { PopupAction } from "@/redux/commonSlice"
import { useAppDispatch } from "@/hooks/reduxHooks"
import { DateFormator, Loading } from "@/GenericFunctions"
import styles from "@/styles/pages/Forms.module.scss"
import { useRouter } from "next/router"
import CryptoJS from "crypto-js"
import Pdf from "react-to-pdf"

const DownloadCertificate = () => {
  const [selectedRequest, setSelectedRequest] = useState<any>({})
  const [districts, setDistricts] = useState<any>([])
  const [locData, setLocData] = useState<any>({})
  const [loggedInAadhar, setLoggedInAadhar] = useState<any>("")
  const [isView, setIsView] = useState<boolean>(false)
  const [isAlreadyDownloaded, setIsAlreadyDownloaded] = useState<boolean>(false)
  const [ispaymentSuccess, setIsPaymentSuccess] = useState<boolean>(false)
  const [signature, setSignature] = useState<string>("")
  const [fullName, setFullName] = useState<string>("")
  const [date, setDate] = useState<any>()

  let ref = React.useRef<HTMLDivElement | null>(null)
  let btnref = React.useRef<HTMLButtonElement | null>(null)

  const router = useRouter()
  const dispatch = useAppDispatch()

  const ShowAlert = (type: boolean, message: string) => {
    dispatch(PopupAction({ enable: true, type: type, message: message }))
  }

  useEffect(() => {
    let data: any = localStorage.getItem("FASPLoginDetails")
    if (data && data != "" && process.env.SECRET_KEY) {
      let bytes = CryptoJS.AES.decrypt(data, process.env.SECRET_KEY)
      data = JSON.parse(bytes.toString(CryptoJS.enc.Utf8))
      Loading(true)
      setLocData(data)
      setLoggedInAadhar(data.aadharNumber)
      instance.get("/getDistricts").then((response) => {
        setDistricts(response.data)
      }).catch(() => {
        console.log("error")
      })
      getFirmDetails(data.applicationId, data.token).then((response) => {
        Loading(false)
        if (response?.success) {
          const date = response.data.firm.processingHistory?.find((x) => x.status == "Approved")
          if (date) {
            setDate(DateFormator(date.applicationProcessedDate, "dd/mm/yyyy"))
          }
          if (response.data.firm.approvedRejectedById) {
            getDeptSignature(response.data.firm.approvedRejectedById, data.token)
              .then((res) => {
                if (res.success && res.data) {
                  setSignature("data:image/jpg;base64, " + res.data.signature)
                  setFullName(res.data.fullName)
                  if(response.data.firm.status == "Approved"){
                  setSelectedRequest(response.data.firm)
                  }
                  else if(response.data.firm.historyDetails?.some((x) => x.status == "Approved")){
                    setSelectedRequest(response.data.firm.historyDetails?.find((x) => x.status == "Approved"))
                  }
                }
              })
              .catch(() => {
                Loading(false)
                console.log("error")
              })
          }

          JsBarcode("#barcode", response.data.firm.applicationNumber, {
            displayValue: false,
          })
          if (response.data.firm.status == "Approved" && response.data.firm.isdownload) {
            setIsAlreadyDownloaded(true)
          } else {
            setIsAlreadyDownloaded(false)
          }
        }
      })
    }
  }, [])

  useEffect(() => {
    if (selectedRequest?.status == "Approved") {
      let data1: any = localStorage.getItem("isdownload")
      if (data1) {
        let data: any = localStorage.getItem("FASPLoginDetails")
        if (data && data != "" && process.env.SECRET_KEY) {
          let bytes = CryptoJS.AES.decrypt(data, process.env.SECRET_KEY)
          data = JSON.parse(bytes.toString(CryptoJS.enc.Utf8))
        }
        api
          .get("/getPaymentDetails/" + data.applicationNumber, {
            headers: {
              Accept: "application/json",
              Authorization: `Bearer ${data.token}`,
            },
          })
          .then((response: any) => {
            if (!response || !response.data || !response.data.success) {
              localStorage.removeItem("isdownload")
              setIsPaymentSuccess(false)
            } else {
              if (
                response.data.data.paymentDetails.transactionStatus == "Success" &&
                !response.data.data.paymentDetails.isUtilized &&
                btnref.current
              ) {
                localStorage.setItem("download", "true")
                btnref.current.click()
                localStorage.removeItem("isdownload")
              } else {
                localStorage.removeItem("isdownload")
                setIsPaymentSuccess(false)
              }
            }
          })
          .catch((error) => {
            localStorage.removeItem("isdownload")
            setIsPaymentSuccess(false)
          })
      }
    }
  }, [selectedRequest])

  const PaymentLink = () => {
    let code = 0
    const dis: any = districts?.find((x: any) => x.name == selectedRequest.district)
    if (dis) {
      code = dis.code
    }
    localStorage.setItem("isdownload", "true")

    const paymentsData = {
      type: "firmsFee",
      source: "Firms",
      deptId: selectedRequest.applicationNumber,
      rmName: selectedRequest.applicantDetails.name,
      rmId: loggedInAadhar,
      mobile: selectedRequest.contactDetails.mobileNumber,
      email: selectedRequest.contactDetails.email,
      drNumber: code,
      rf: 300,
      uc: 0,
      oc: 0,
      returnURL: process.env.BACKEND_URL + "/firms/redirectcertificate",
    }
    let paymentRedirectUrl = process.env.PAYMENT_REDIRECT_URL
    let encodedData = Buffer.from(JSON.stringify(paymentsData), "utf8").toString("base64")
    console.log("ENCODED VALUE IS ", encodedData)
    let paymentLink = document.createElement("a")
    paymentLink.href = paymentRedirectUrl + encodedData
    paymentLink.click()
    setTimeout(function () {
      paymentLink.remove()
    }, 1000)
  }

  const options = {
    orientation: "p",
    unit: "mm",
    format: [400, 270],
  }

  return (
    <>
      <Head>
        <title>Acknowledgement of Registration of Firm</title>
        <link rel="icon" href="/igrsfavicon.ico" />
      </Head>
      {locData && locData?.userType && locData?.userType == "user" && (
        <div className={styles.RegistrationMain}>
          <div className="societyRegSec">
            <Container>
              <Row>
                <Col lg={12} md={12} xs={12}>
                  <div className="d-flex justify-content-between align-items-center page-title mb-2">
                    <div className="pageTitleLeft">
                      <h1>Firm Certificate</h1>
                    </div>

                    <div className="pageTitleRight">
                      {/* <div className="page-header-btns">
                        <a
                          className="btn btn-primary new-user"
                          onClick={() => router.push("dashboard")}
                        >
                          Go Back
                        </a>
                      </div> */}
                    </div>
                  </div>
                </Col>
              </Row>
            </Container>
            {selectedRequest?.status == "Approved" && selectedRequest.applicationNumber ? (
              <Pdf
                targetRef={ref}
                filename={`${selectedRequest.applicationNumber}.pdf`}
                options={options}
                x={20}
                y={0}
                scale={0.8}
              >
                {({ toPdf }: any) => (
                  <div className="text-center">
                    <Button
                      id="downloadClick"
                      ref={btnref}
                      className="ms-3"
                      variant="primary"
                      onClick={() => {
                        const data = localStorage.getItem("download")
                        if (data == "true") {
                          toPdf()
                          downloadFirmCertificate(
                            { amount: 300, appId: locData.applicationNumber },
                            locData.applicationId,
                            locData.token
                          )
                          ShowAlert(true, "Your certificate is downloaded successfully")
                          localStorage.removeItem("download")
                        } else if (!isAlreadyDownloaded) {
                          toPdf()
                          downloadFirmCertificate(
                            { amount: 0 },
                            locData.applicationId,
                            locData.token
                          )
                          ShowAlert(true, "Your certificate is downloaded successfully")
                          setIsAlreadyDownloaded(true)
                        } else {
                          PaymentLink()
                        }
                      }}
                    >
                      Download Certificate
                    </Button>
                  </div>
                )}
              </Pdf>
            ):
            <div className="societyRegSec">
            <Container>
              <Row>
                <Col lg={12} md={12} xs={12}>
                  <div className="d-flex justify-content-center page-title mb-2">
                    <div className="pageTitleLeft">
                      <h1>Application is not yet approved</h1>
                    </div>
                  </div>
                </Col>
              </Row>
            </Container>
          </div>}
            {selectedRequest && (
              <div
                style={{
                  position: "absolute",
                  left: "-999em",
                  right: "0",
                  margin: "auto",
                  width: "100%",
                }}
                className="societyRegSec"
                id="viewSocietyCerticate"
              >
                <div className="viewCertificatePage">
                  <div className="pageWrapper">
                    <div className="viewCerticateSec">
                      <Container ref={ref}>
                        <div className="certificateHeader">
                          <div className="certificateHeaderLogo">
                            <img
                              src="/assets/Andhra_Pradesh_Official_Logo.jpg"
                              alt="Andhra_Pradesh_Official_Logo.jpg"
                              title=""
                            />
                          </div>
                          <h1>
                            GOVERNMENT OF ANDHRA PRADESH REGISTRATION AND STAMPS DEPARTMENT THE
                            REGISTRAR OF FIRMS
                          </h1>
                          <h5>Acknowledgement of Registration of Firm</h5>
                        </div>

                        <div className="certificateReg">
                          <Row className="d-flex justify-content-between align-items-center">
                            <Col md={{ span: 6, offset: 2 }}></Col>
                            <Col lg={4} md={4} xs={12}>
                              <div className="certificateInfo">
                                <h6>Application No </h6>
                                <img id="barcode" />
                                <h5>{selectedRequest.applicantNumber}</h5>
                                <h6>Date: {date}</h6>
                              </div>
                            </Col>
                          </Row>
                        </div>

                        <div className="certificateHereInfo">
                          <p>
                            The Registrar of Firms, hereby acknowledges the receipt of the statement
                            prescribed by section 58(1) of the Indian Partnership Act. 1932.
                          </p>
                          <p>
                            The statement has been filed and the name of the firm, has been entered
                            in the Register of Firms as No. No: {selectedRequest.registrationNumber}{" "}
                            of {selectedRequest.registrationYear} at Registration District{" "}
                            {selectedRequest.district}
                          </p>
                        </div>

                        <div className="certifyLogoSec">
                          <Row className="d-flex justify-content-between align-items-center">
                            <Col lg={6} md={6} xs={12}>
                              <div className="certifyLogoInfo text-center">
                                <div className="certifyLogoImgSec">
                                  <img src="/assets/seal_firm.png" alt="seal_firm.png" />
                                  <h6>{selectedRequest?.district}</h6>
                                </div>
                                <h6>Date: {date}</h6>
                              </div>
                            </Col>

                            <Col lg={6} md={6} xs={12}>
                              <div className="certifySignInfo">
                                <h6>Certified By</h6>
                                <div className="certifySignImg">
                                  <img src={signature} alt="signImg.png" />
                                </div>
                                <h6>Name: {fullName}</h6>
                                <h6>Designation: DISTRICT REGISTRAR</h6>
                                <h6>District: : {selectedRequest?.district}</h6>
                              </div>
                            </Col>
                          </Row>
                        </div>

                        <div className="certifyTopTitle text-center">
                          <h2>FORM-A</h2>
                          <h2>SEE RULE - 5</h2>
                        </div>

                        <div className="certifyMaintainSec text-center">
                          <h3>(Maintained Under Section 59 of the Indian Partnership Act, 1932)</h3>
                        </div>

                        <Table striped bordered className="certifiyTable">
                          <tbody>
                            <tr>
                              <td>1</td>
                              <td>Serial Number Of Firm:</td>
                              <td>
                                No: {selectedRequest.registrationNumber} of{" "}
                                {selectedRequest.registrationYear}
                              </td>
                            </tr>

                            <tr>
                              <td>2</td>
                              <td>Name Of The Firm:</td>
                              <td>{selectedRequest.firmName}</td>
                            </tr>

                            <tr>
                              <td>3</td>
                              <td>Duration Of Firm From:</td>
                              <td>{selectedRequest.firmDurationFrom}</td>
                            </tr>

                            <tr>
                              <td>4</td>
                              <td>Duration Of Firm To:</td>
                              <td>{selectedRequest.firmDurationTo}</td>
                            </tr>
                          </tbody>
                        </Table>

                        <div className="certifyMaintainSec text-center">
                          <h3>Principal Place of Business for the Firm</h3>
                        </div>

                        <Table striped bordered className="certifiyTable">
                          <thead>
                            <tr>
                              <th>S.No</th>
                              <th>Door No</th>
                              <th>Street</th>
                              <th>District</th>
                              <th>Mandal</th>
                              <th>Village/City</th>
                              <th>PIN Code</th>
                            </tr>
                          </thead>

                          {selectedRequest.principalPlaceBusiness &&
                          selectedRequest.principalPlaceBusiness.length > 0 ? (
                            <tbody>
                              {selectedRequest.principalPlaceBusiness.map(
                                (item: any, i: number) => {
                                  return (
                                    <tr key={i + 1}>
                                      <td>1</td>
                                      <td>{item.doorNo}</td>
                                      <td>{item.street}</td>
                                      <td>{item.district}</td>
                                      <td>{item.mandal}</td>
                                      <td>{item.villageOrCity}</td>
                                      <td>{item.pinCode}</td>
                                    </tr>
                                  )
                                }
                              )}
                            </tbody>
                          ) : (
                            <tbody>
                              <tr>
                                <td colSpan={6}>No Principal Place of Business Found</td>
                              </tr>
                            </tbody>
                          )}
                        </Table>

                        <div className="certifyMaintainSec text-center">
                          <h3>Partner Details for the Firm</h3>
                        </div>

                        <Table striped bordered className="certifiyTable">
                          <thead>
                            <tr>
                              <th className="text-center">S.No</th>
                              <th>Partner Name</th>
                              <th>Age</th>
                              <th>Joining Date</th>
                              <th>Partner Address</th>
                            </tr>
                          </thead>

                          {selectedRequest.firmPartners &&
                          selectedRequest.firmPartners.length > 0 ? (
                            <tbody>
                              {selectedRequest.firmPartners.map((item: any, i: number) => {
                                return (
                                  <tr key={i + 1}>
                                    <td>{i + 1}</td>
                                    <td>{item.partnerName}</td>
                                    <td>{item.age}</td>
                                    <td>{DateFormator(item.joiningDate, "dd/mm/yyyy")}</td>
                                    <td>{`${item.doorNo}/${item.street}/${item.villageOrCity}/${item.mandal}/${item.district}/${item.state}/${item.country}`}</td>
                                  </tr>
                                )
                              })}
                            </tbody>
                          ) : (
                            <tbody>
                              <tr>
                                <td colSpan={6}>No Partners Found</td>
                              </tr>
                            </tbody>
                          )}
                        </Table>

                        <div className="certifyMaintainSec text-center">
                          <h3>Document Details</h3>
                        </div>

                        <Table striped bordered className="certifiyTable">
                          <thead>
                            <tr>
                              <th>Document Type</th>
                              <th>Document Name</th>
                            </tr>
                          </thead>

                          {selectedRequest?.documentAttached &&
                          selectedRequest?.documentAttached?.length > 0 ? (
                            <tbody>
                              {selectedRequest?.documentAttached?.map(
                                (document: any, index: number) => {
                                  const appName = document?.originalname
                                  const appSplit = appName.split("_")
                                  let appSplitVal = appSplit[0]
                                  let appType = ""

                                  if (appSplitVal == "partnershipDeed") {
                                    appType = "Partnership Deed"
                                  }
                                  if (appSplitVal == "leaseAgreement") {
                                    appType = "Lease Agreement"
                                  }
                                  if (appSplitVal == "affidavit") {
                                    appType = "Affidavit"
                                  }
                                  if (appSplitVal == "selfSignedDeclaration") {
                                    appType = "Self signed declaration"
                                  }
                                  return (
                                    <tr key={index + 1}>
                                      <td>{appType}</td>
                                      <td>{document?.originalname}</td>
                                    </tr>
                                  )
                                }
                              )}
                            </tbody>
                          ) : (
                            <tbody>
                              <tr>
                                <td colSpan={6}>No Documents Found</td>
                              </tr>
                            </tbody>
                          )}
                        </Table>

                        <div className="certificateBtnSec"></div>
                      </Container>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {selectedRequest?.status == "Incomplete" && (
              <div className="applicationPendingSec">
                <Row className="d-flex justify-content-between align-items-center">
                  <Col lg={12} md={12} xs={12}>
                    <div className="certificateHeader text-center">
                      <h3>Your application is not yet submitted </h3>
                    </div>
                  </Col>
                </Row>
              </div>
            )}
            {selectedRequest?.status &&
              selectedRequest?.status != "" &&
              selectedRequest?.status != "Approved" &&
              selectedRequest?.status != "Incomplete" && (
                <div className="applicationPendingSec">
                  <Container>
                    <Row className="d-flex justify-content-between align-items-center">
                      <Col lg={12} md={12} xs={12}>
                        <div className="certificateHeader text-center">
                          <h3>Your application is pending </h3>
                        </div>
                      </Col>
                    </Row>
                  </Container>
                </div>
              )}
          </div>
        </div>
      )}
      {(!locData?.userType || locData?.userType != "user") && (
        <div className="societyRegSec">
          <Container>
            <Row>
              <Col lg={12} md={12} xs={12}>
                <div className="d-flex justify-content-between page-title mb-2">
                  <div className="pageTitleLeft">
                    <h1>Unauthorized page</h1>
                  </div>
                </div>
              </Col>
            </Row>
          </Container>
        </div>
      )}
    </>
  )
}

export default DownloadCertificate
