import React from "react"

const logOff = () => {
  return <div>logOff</div>
}

export default logOff
